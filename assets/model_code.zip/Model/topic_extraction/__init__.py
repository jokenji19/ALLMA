"""Topic extraction module"""

from .topic_extractor import TopicExtractor

__all__ = ['TopicExtractor']
