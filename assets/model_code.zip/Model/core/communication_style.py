"""Stili di comunicazione supportati dal sistema"""

from Model.user_system.user_preferences import CommunicationStyle

# Re-export CommunicationStyle
__all__ = ['CommunicationStyle']
